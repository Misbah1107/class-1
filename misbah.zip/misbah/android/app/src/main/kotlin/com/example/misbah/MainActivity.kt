package com.example.misbah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
